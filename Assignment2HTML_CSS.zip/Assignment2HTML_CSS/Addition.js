var num1 = 5;
let num2 = 3;

var sum = num1 + num2;
var sub=num1-num2;
var mul=num1*num2;
var div=num1/num2;

console.log('The sum of ' + num1 + ' and ' + num2 + ' is: ' + sum);
console.log('The sub of ' + num1 + ' and ' + num2 + ' is: ' + sub);
console.log('The mul of ' + num1 + ' and ' + num2 + ' is: ' + mul);
console.log('The sdiv of ' + num1 + ' and ' + num2 + ' is: ' + div);