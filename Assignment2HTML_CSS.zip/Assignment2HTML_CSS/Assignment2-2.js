

console.log("HELLO WORLD");

var num1=10;
let num2=34.54;
var s1="manoj";
let s2="BHOYE";

console.log("Hello CDAC");
console.log("---------------");
console.log(num1);
console.log("---------------");
console.log(num2);
console.log("---------------");
console.log(s1);
console.log("---------------");
console.log(s2);
console.log("---------------");
console.log(s1==s2);
console.log("---------------");
console.log(s1.length);
console.log("---------------");
console.log(s2.toLowerCase());
console.log("---------------");
console.log(s1.toUpperCase());
console.log("---------------");
console.log(s1.concat(s2));
console.log("---------------");
console.log(s1.charAt(1));
console.log("---------------");
console.log(s2.charAt(4));
console.log("---------------");
console.log(s1.slice(1));
console.log("---------------");
console.log(s2.sub(1));
console.log("---------------");
console.log(s1.includes("no"));
console.log("---------------");
console.log(s1.indexOf("j"));


